package com.jakesajao.githubAnalytics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GithubAnalyticsApplicationTests {

	@Test
	void contextLoads() {
	}

}
