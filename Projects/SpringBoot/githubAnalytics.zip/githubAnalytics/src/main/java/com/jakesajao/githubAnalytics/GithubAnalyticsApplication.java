package com.jakesajao.githubAnalytics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GithubAnalyticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GithubAnalyticsApplication.class, args);
	}

}
