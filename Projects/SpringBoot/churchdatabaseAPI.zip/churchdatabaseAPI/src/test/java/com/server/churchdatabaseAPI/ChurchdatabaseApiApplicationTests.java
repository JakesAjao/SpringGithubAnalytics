package com.server.churchdatabaseAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChurchdatabaseApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
